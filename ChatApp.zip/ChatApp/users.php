<?php 
  session_start();
  include_once "php/config.php";
   if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>
<?php include_once "header.php"; ?>
<body>
  <div class="wrapper" id="demo1">
    <section class="users">
      <header>
        <div class="content">
          <?php 
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if(mysqli_num_rows($sql) > 0){
              $row = mysqli_fetch_assoc($sql);
            }
          ?>

        <button type="button" onclick="show()" style="background-color:transparent; border:none;"> <img src="php/images/<?php echo $row['img']; ?>" alt=""> </button>
          <div class="details">
            <span><?php echo $row['fname']. " " . $row['lname'] ?></span>
            <p><?php echo $row['status']; ?></p>
      <!-- here we joined js and php but if you want u can separate it -->
      <script>
      function show() {
         document.getElementById("demo").style.display = "block";
         document.getElementById("demo1").style.display = "none";
      }
      function hide() {
         document.getElementById("demo").style.display = "none";
         document.getElementById("demo1").style.display = "block";
      }
   </script>
          </div>
        </div>
        <a href="php/logout.php?logout_id=<?php echo $row['unique_id']; ?>" class="logout">Logout</a>
      </header>
      <div class="search">
        <span class="text">Select an user to start chat</span>
        <input type="text" placeholder="Enter name to search...">
        <button><i class="fas fa-search"></i></button>
      </div>
      <div class="users-list">
  
      </div>
    </section>
  </div>

  <script src="javascript/users.js"></script>

<!-- the profile starts -->


      <div hidden class="profile-container" id="demo">
      <a href="index.php" style="position:absolute; margin-left:150px;"><span style="font-size: 34px;" class="material-icons">home</span></a>
         <div class="profile-wrapper">
            <a href="#">
            <img class="img1" src="php/images/<?php echo $row['img']; ?>" alt="">
            </a>
            <div class="profile-title">
            <?php echo $row['fname']. " " . $row['lname'] ?>
            </div>
            <div class="profile-buttons">
               <div class="profile-btn">
                  <button><a href="create.php">Add Post</a></button>
               </div>
               <div class="profile-btn">
                  <button type="button" onclick="hide()">Back to chat</button>
               </div>
            </div>
            <div class="profile-place">
              <?php echo $row['location'] ?>
            </div>
         </div>
         <div class="profile-content">
            <p>
               User Interface Designer and <br>front-end developer
            </p>
         </div>
         
      </div>
      <script>
         const img = document.querySelector(".img1");
         const icons = document.querySelector(".icons");
         img.onclick = function(){
           this.classList.toggle("active");
           icons.classList.toggle("active");
         }
      </script>
 
</body>
</html>
