<?php 
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>
<?php include_once "header.php"; ?>
<body>
  <div class="wrapper" id="chat">
    <section class="chat-area">
      <header>
        <?php 
          $user_id = mysqli_real_escape_string($conn, $_GET['user_id']);
          $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$user_id}");
          if(mysqli_num_rows($sql) > 0){
            $row = mysqli_fetch_assoc($sql);
          }else{
            header("location: users.php");
          }
        ?>
        <a href="users.php" class="back-icon"><i class="fas fa-arrow-left"></i></a>
        <button onclick="show()" type="button" style="background-color:transparent; border:none;"><img src="php/images/<?php echo $row['img']; ?>"></button>
        <div class="details">
          <span><?php echo $row['fname']. " " . $row['lname'] ?></span>
          <p><?php echo $row['status']; ?></p>
        </div>
      </header>

            <!-- here we joined js and php but if you want u can separate it -->
            <script>
      function show() {
        document.getElementById("usr-prof").style.display = "block";
        document.getElementById("chat").style.display = "none";
      }
      function hide() {
        document.getElementById("usr-prof").style.display = "none";
        document.getElementById("chat").style.display = "block";
      }
   </script>
      <div class="chat-box">

      </div>
      <form action="#" class="typing-area">
        <input type="text" class="incoming_id" name="incoming_id" value="<?php echo $user_id; ?>" hidden>
        <input type="text" name="message" class="input-field" placeholder="Type a message here..." autocomplete="off">
        <button><i class="fab fa-telegram-plane"></i></button>
      </form>
    </section>
  </div>

  <script src="javascript/chat.js"></script>


  <!-- this is the profile of who are u chatting with-->

  
  <div hidden class="profile-container" id="usr-prof">
         <div class="profile-wrapper">
            <a href="#">
            <img class="img1" src="php/images/<?php echo $row['img']; ?>" alt="">
            </a>
            <div class="profile-title">
            <?php echo $row['fname']. " " . $row['lname'] ?>
            </div>
            <div class="profile-buttons">
               <div class="profile-btn">
                  <button>Block this Person</button>
               </div>
               <div class="profile-btn">
                  <button type="button" onclick="hide()">Back to chat</button>
               </div>
            </div>
            <div class="profile-place">
              Location: <?php echo $row['location'] ?>
            </div>
         </div>
         <div class="profile-content">
            <p>
               User Interface Designer and <br>front-end developer
            </p>
         </div>
         
      </div>
      <script>
         const img = document.querySelector(".img1");
         const icons = document.querySelector(".icons");
         img.onclick = function(){
           this.classList.toggle("active");
           icons.classList.toggle("active");
         }
      </script>
</body>
</html>
