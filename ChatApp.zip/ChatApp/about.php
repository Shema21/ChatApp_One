<?php 
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>
<?php include_once "header.php"; ?>
<body>
<div class="profile-container">
<br>
<a href="index.php" style="position:absolute; margin-left:150px;"><span style="font-size: 34px;" class="material-icons">home</span></a>
<h1>About Us</h1>
<p style="margin-top: 30px; float:left; margin-left:20px;"><b>Chattinga: </b>
is wide chatting website which is<br> secured than any chatting
website you knew<br> and is safe if you want to chat a secured<br>
conversations.
<br>
<br>
<b>Shema Landry:</b> Is developer of chattinga <br><br>
You can Write feedback on our<br> Gmail <b style="color:blue;">chattinga@gmail.com</b><br>
Call us on: +250790655527<br><br>
write on Facebook: <b>Creater Shema</b><br>
so,enjoy our site.
Thank you!
</p>
<footer style="margin-top:500px;">Shema Landry &copy Copyright2021</footer>
</body>
</html>