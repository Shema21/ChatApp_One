<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>test</title>
</head>
<body>
<div class="profile-container" id="usr-prof">
         <div class="profile-wrapper">
            <a href="#">
            <img class="img1" src="php/images/<?php echo $row['img']; ?>" alt="">
            </a>
            <div class="profile-title">
            <?php echo $row['fname']. " " . $row['lname'] ?>
            </div>
            <div class="profile-buttons">
               <div class="profile-btn">
                  <button>Block this Person</button>
               </div>
               <div class="profile-btn">
                  <button type="button" onclick="hide()">Back to chat</button>
               </div>
            </div>
            <div class="profile-place">
              Location: <?php echo $row['location'] ?>
            </div>
         </div>
         <div class="profile-content">
            <p>
               User Interface Designer and <br>front-end developer
            </p>
         </div>
         
      </div>
</body>
</html>