<!DOCTYPE html>
<?php 
$pdo = new PDO('mysql:host=localhost;port=3386;dbname=chattinga', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$statement = $pdo->prepare('SELECT * FROM post ORDER BY post_id DESC');
$statement->execute();
$posts = $statement->fetchAll(PDO::FETCH_ASSOC);
$statement1 = $pdo->prepare('SELECT * FROM post');
$likes = $statement1->fetchAll(PDO::FETCH_ASSOC);
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chattinga home page</title>
    <link rel="stylesheet" href="homecss.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
</head>
<body>
      
<div class="app_videos">

    <!-- video starts-->
    <?php foreach ($posts as $post):  ?>
    <div class="video">
        <video src="<?php echo $post['url'] ?>" name="video" class="video_player"></video>
        <!-- sidebar -->

        <div class="videosidebar">
            <div class="videosidebar_button">
            <form method="POST">
            <span class="material-icons">favorite_border</span>
            <p name="savelikes">10</p>
            </form>
            </div>

            <div class="videosidebar_button">
            <span class="material-icons">chat</span>
                <p>22</p>
            </div>

            <div class="videosidebar_button">
            <span class="material-icons">share</span>
                <p>72</p>
            </div>
        </div>

    <!-- footer -->
    <div class="videofooter">
    <div class="videofooter_text">
        <h3>shema landry</h3>
        <p class="videofooter_description">
       <?php echo $post['description'] ?>
        </p>
    </div>
    </div>

    </div>
    <?php endforeach; ?>
    <!--video ends-->
   


    </div>
    </div>


    <!-- nab bars -->
    <div class="nav-bar">
    <div class="nav-icons">
    <a href="index.php"><span class="material-icons">home</span></a>
    <a href="search/search.php"><span class="material-icons">search</span></a>
    <a href="create.php"><span class="material-icons">add</span></a>
    <a href="users.php"><span class="material-icons">mail</span></a>
    <a href="profile.php"><span class="material-icons">person</span></a>
    </div>

<script>
    const videos = document.querySelectorAll('video');
    for(const video of videos){
        video.addEventListener('click', function(){
            if (video.paused) {
            video.play();
            }else{
                video.pause();
            }
        })
        }
</script>
</body>
</html>
