<!DOCTYPE html>
<html>
<head>
<?php 
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
  
?>


<?php


// making connection between database and html page
$pdo = new PDO('mysql:host=localhost;port=3386;dbname=chattinga', 'root', '');

// if an error accours during the connection
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

   $type = $_POST['video_type'];
   $desc = $_POST['description1'];

   // if image doesn't exists then create it
   if (!is_dir('videos')) {
      mkdir('videos');
   }


   $url = $_FILES['video_url'] ?? null;
    $videoPath = '';

       // if image exists
      if ($url && $url['tmp_name']) {
       // this will create a unique folder
         $videoPath = 'videos/'.randomString(8).'/'.$url['name'];
         mkdir(dirname($videoPath));
         
         // this will move an image from tmp_name to specified image path
         // becouse every image is kept in tmp_name
         move_uploaded_file($url['tmp_name'], $videoPath);
      }




      // for saving into data database
      $statement = $pdo->prepare("INSERT INTO post (type, url, description)
                                 VALUES (:type1, :url1, :description1) ");
      $statement->bindValue(':type1', $type);
      $statement->bindValue(':url1', $videoPath);
      $statement->bindValue(':description1', $desc);
      $statement->execute();
      header ('Location: index.php');
      

}


// this will generate a random string for an image folder container
function randomString($n)
{
    $characters = 'QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890';
    $str = '';
    for ($i=0; $i < $n; $i++) { 
        $index = rand(0, strlen($characters) - 1);
        $str .= $characters[$index];
    }

    return $str;
}






?>
   <title> Create Post </title>
   <link rel="stylesheet" href="post.css">
   <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
  
</head>
<body>

   <h2 style="text-align: center;"> Create Post </h2>
   <div class="form-container">

      <form action="" method="POST" enctype="multipart/form-data">
      <a href="index.php" style="position:absolute;"><span style="font-size: 34px;" class="material-icons">home</span></a>
      	<div class="post">
         <h4>video type</h4>
            <input type="text" placeholder="post type here...." name="video_type" required>
         
            <h4>choose video</h4>
            <input type="file" name="video_url">

            <h4>description</h4>
            <textarea placeholder="Your description here..." name="description1" required></textarea>

            <br>
            <button type="submit">Create Post</button>

         </div>
           
         
      </form>
      
   </div>

</body>
</html>
