<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>update profile</title>
  <link rel="stylesheet" href="style.css">
</head>
<?php
$pdo = new PDO('mysql:host=localhost;port=3386;dbname=chattinga', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$id = $_GET['id'] ?? null;

$statement = $pdo->prepare('SELECT * FROM users WHERE unique_id = :id');
$statement->bindValue(':id', $id);
$statement->execute();
$user = $statement->fetch(PDO::FETCH_ASSOC);
/*echo '<pre>';
var_dump($user);
echo '</pre>';
exit; */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = $user['fname'];
    $lname = $user['lname'];
    $email = $user['email'];
    $location = $user['location'];
    $password = $user['password'];

      $fname = $_POST['fname'];
      $lname = $_POST['lname'];
      $email = $_POST['email'];
      $location = $_POST['location'];
      $password = $_POST['password'];

      $statement = $pdo->prepare("UPDATE users SET fname = :fname, lname = :lname, email = :email, location = :location1, password = :password1 WHERE unique_id = :id");
      $statement->bindValue(':fname', $fname);
      $statement->bindValue(':lname', $lname);
      $statement->bindValue(':email', $email);
      $statement->bindValue(':location1', $location);
      $statement->bindValue(':password1', $password);
      $statement->bindValue(':id', $id);
      $statement->execute();
      header('Location: profile.php');
}
?>
<body>
  <div class="wrapper">
    <section class="form signup">
    <a href="index.php" style="position:absolute;"><span style="font-size: 34px;" class="material-icons">home</span></a>
      <header>Chattinga</header>
      <form action="" method="POST" enctype="multipart/form-data" autocomplete="off">
        <div class="error-text"></div>

        <div class="name-details">
        <img class="img1" width="170px" height="170px" src="php/images/<?php echo $user['img']; ?>" alt="">
              <break>
          <div class="field input">
            <label>First Name</label>
            <input type="text" name="fname" placeholder="<?php echo $user['fname'] ?>" required>
          </div> 
          <div class="field input">
            <label>Last Name</label>
            <input type="text" name="lname" placeholder="<?php echo $user['lname'] ?>" required>
          </div>
        </div>
        <div class="field input">
          <label>Email Address</label>
          <input type="text" name="email" placeholder="<?php echo $user['email'] ?>" required>
        </div>
        <div class="field input">
          <label>Location</label>
          <input type="text" name="location" placeholder="<?php echo $user['location'] ?>" required>
        </div>
        <div class="field input">
          <label>Password</label>
          <input type="password" name="password" placeholder="Set new password" required>
          <i class="fas fa-eye"></i>
        </div>
        <div class="field button" style="display:inline-block;">
          <input type="submit" name="submit" value="Update profile">
          
        </div>
      <button class="cancel-button"> <a style="color:white;text-decoration:none;" href="profile.php">Cancel</a></button?>
      </form>
    </section>
  </div>
  <script src="javascript/pass-show-hide.js"></script>
</body>
</html>



        