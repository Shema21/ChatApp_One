<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <?php /*
  session_start();
  include_once "../php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  } */
?>
  <?php
$pdo = new PDO('mysql:host=localhost;port=3386;dbname=chattinga', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$search = $_GET['search'] ?? '';
if ($search) {
    $statement = $pdo->prepare('SELECT * FROM users WHERE fname LIKE :result1 OR lname LIKE :result2');
    $statement->bindValue(':result1', "%$search%");
    $statement->bindValue(':result2', "%$search%");
}else {
  $statement = $pdo->prepare('SELECT * FROM users');   
}
$statement->execute();
$users = $statement->fetchAll(PDO::FETCH_ASSOC);
?>
    <meta charset="utf-8">
    <title>search</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  </head>
  <body>
    <form method="GET" style="display:inline-block;">
    <div class="container">
       <div class="search-box">
    <a href="../index.php" class="back-icon"><i class="fas fa-arrow-left"></i></a>
      <input type="text" placeholder="search freinds here.." name="search" value="<?php echo $search ?>">
      <div class="search-icon">
      <button class="search-btn" type="submit"><i class="fas fa-search"></i></button>
      </div>
      <br><br>
      <hr>
      </form>

      <!-- search results -->

<?php foreach ($users as $user) : ?>
    <a href="../chat.php?user_id=<?php echo $user['unique_id']; ?>">
    <div class="result">
      <img src="../php/images/<?php echo $user['img'] ?>" alt="">
      <h3><?php echo $user['fname']. " " . $user['lname'] ?></h3>
      <h5><?php echo $user['location'] ?></h5>
  </div>
  </a>
<?php endforeach; ?>
</div>
</div>
</div>
  </body>
</html>