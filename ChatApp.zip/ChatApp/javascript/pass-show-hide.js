// this will be assigned to input type password 
const pswrdField = document.querySelector(".form input[type='password']"),
// this is used to pick eye icon
toggleIcon = document.querySelector(".form .field i");

// if eye icon is clicked
// this will change the type of input text which by defoult
// is password to text else to password
toggleIcon.onclick = () =>{
  if(pswrdField.type === "password"){
    pswrdField.type = "text";
    toggleIcon.classList.add("active");
  }else{
    pswrdField.type = "password";
    toggleIcon.classList.remove("active");
  }
}


// created by shema landry
