<?php 
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>

<?php include_once "header.php"; ?>

<?php 
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if(mysqli_num_rows($sql) > 0){
              $row = mysqli_fetch_assoc($sql);
            }
          ?>
<body>
<!-- the profile starts -->
<div class="profile-container" id="demo">
<a href="index.php" style="position:absolute; margin-left:150px;"><span style="font-size: 34px;" class="material-icons">home</span></a>
         <div class="profile-wrapper">
            <a href="#">
            <img class="img1" src="php/images/<?php echo $row['img']; ?>" alt="">
            </a>
            <div class="profile-title">
            <?php echo $row['fname']. " " . $row['lname'] ?>
            </div>
            <div class="profile-buttons">
               <div class="profile-btn">
                  <button><a style="color:white;text-decoration:none;" href="update-profile.php?id=<?php echo $row['unique_id']?>">Edit Profile</a></button>
               </div>
               
               <div class="profile-btn">
                  <button type="button" onclick="hide()"><a style="color:white;" href="users.php">Back to chat</a></button>
               </div>
            </div>
            <div class="profile-place">
              Location: <?php echo $row['location'] ?>
            </div>
         </div>
         <div class="profile-content">
            <br>
            <p>
               <?php echo $row['email'] ?>
            </p>
            <br><br><br><br><br>
            <footer style="background-color:rgb(230,230,230);"><a style="text-decoration:none;"href="about.php">AboutUs</a></footer>
         </div>
         
      </div>
      
      <script>
         const img = document.querySelector(".img1");
         const icons = document.querySelector(".icons");
         img.onclick = function(){
           this.classList.toggle("active");
           icons.classList.toggle("active");
         }
      </script>

</body>
</html>